# tclsignal
TCL Signal Ext. Tcl 8.5/8.6 TEA compatible. Based on signal_ext version 1.4.0.1 by Michael Schwartz.
